<?php

//2601
//sql

/*static function sqcols_0($b){//dont give length of int
$rq=self::qr(self::schema($b));
while($r=mysqli_fetch_assoc($rq)){
$rt[$r['COLUMN_NAME']]=[$r['DATA_TYPE'],$r['CHARACTER_MAXIMUM_LENGTH']];}
return $rt;}*/

/*static function describe($b){//better infos of sizes
$r=self::call('describe '.$b); $rt=[]; $sz='';
foreach($r as $k=>[$col,$ty]){//Field,Type,Null,Key,Default,Extra
if(strpos($ty,'(')){[$typ,$sz]=split_one('(',$ty); $sz=substr($sz,0,-1);} else{$typ=$ty; $sz='';}
$rt[$col]=[$typ,$sz];}
return $rt;}*/

///coltypes
//$r=self::describe($b);

/**/

/*static function up($b,$d,$v,$q,$col='',$z=''){if($col)$q=[$col=>$q];
self::qr('update '.$b.' set '.self::escr([$d=>$v]).' '.self::setq($q,$b),$z);}*/

//trans
/*static function api_old($prm,$txt,$mode=''){
$txt=str::utf8enc($txt);
$prm['auth_key']=self::getkey();
$mode=$mode?$mode:'translate';
$u='https://api-free.deepl.com/v2/'.$mode.'?'.implode_k($prm,'&','=');
$ret=self::post($u,$txt);
$r=json_decode($ret,true); //pr($r);
if(isset($r['message'])){echo $r['message']; $r=['text'=>$txt];}
else $r=$r['translations'][0]??'';
return $r;}*/

//sql
#update structure
/*static function trigger($b,$ra){if(!self::ex($b))return;
$rb=self::cols($b); $rnew=[]; $rold=[];
if(isset($rb['id']))unset($rb['id']); if(isset($rb['up']))unset($rb['up']);
if($rb){$rnew=array_diff_assoc($ra,$rb); $rold=array_diff_assoc($rb,$ra);}//old
if($rnew or $rold){//pr([$rnew,$rold]);
	$bb=self::backup($b,date('ymdHis')); self::drop($b);
	$rtwo=array_intersect_assoc($ra,$rb);//common
	$rak=array_keys($ra); $rav=array_values($ra);
	$rnk=array_keys($rnew); $rnv=array_values($rnew); $nn=count($rnk);
	$rok=array_keys($rold); $rov=array_values($rold); $no=count($rok);
	$na=count($rnew); $nb=count($rold); $ca=array_keys($rtwo); $cb=array_keys($rtwo);
	if($na==$nb)for($i=0;$i<$nn;$i++)if($rnv[$i]==$rov[$i] or $rnv[$i]!='int'){
		$ca[]=$rnk[$i]; $cb[]=$rok[$i];}
	return 'insert into '.$b.'(id,'.implode(',',$ca).',up) select id,'.implode(',',$cb).',up from '.$bb;}}*/

//tlex
/*static function apisql0($p,$z=0){//pr($p);
$ra=['tm','th','id','ib','ia','srh','ntf','from','since','list','noab','labl','count','app','tag','mnt','see','mode','likes'];
[$usr,$th,$id,$ib,$ia,$srh,$ntf,$from,$since,$list,$noab,$labl,$count,$app,$tag,$mnt,$see,$mode,$liks]=vals($p,$ra);
if($from=='wrp')return;
$vm='rr'; $gr=''; $ord=''; $db=self::$db; $sqin=[]; $us=ses('usr'); $usid=ses('uid');
$cfg=['profile','like','labels'];
if(!$noab){$cfg[]='members'; $cfg[]='mentions';}
//if($labl or $see=='labl')$cfg[]='labels'; else
if($tag or $see=='tag')$cfg[]='tags';
//elseif($app or $see=='app')
$cfg[]='apps'; //pr($cfg);
$sqcl[]=$db.'.id,uid,txt,lg,pv,ib,ko,unix_timestamp('.$db.'.up) as now,name';
$sqin[]='left join login on login.id=uid'; //pr($cfg);
foreach($cfg as $k=>$v)//activations
	//if($v=='profile'){$sqcl[]='pname,avatar,clr,privacy'; $sqin[]='left join profile on puid=uid';}
	//elseif($v=='like'){$sqcl[]='tlex_lik.id as lid'; $sqin[]='left join tlex_lik on '.$db.'.id=lik';}
	if($v=='members'){$sqcl[]='list';//usr,ab
		if($mode=='public' or $tag or $app)$abs=''; else $abs=' and tlex_ab.usr="'.$usid.'"';
		$sqin[]='left join tlex_ab on '.$db.'.uid=ab and wait=0 and block=0'.$abs;}
	elseif($v=='labels'){$sqcl[]='ref,icon,lbl'; $sqin[]='left join labels on lbl=labels.id';}
	elseif($v=='mentions'){$sqcl[]='tousr'; $sqin[]='left join tlex_mnt on '.$db.'.id=tlex_mnt.tlxid';}
	elseif($v=='tags'){$sqcl[]='tag'; $sqin[]='left join tlex_tag on '.$db.'.id=tlex_tag.tlxid';}
	elseif($v=='apps'){$sqcl[]='app,p'; $sqin[]='left join tlex_app on '.$db.'.id=tlex_app.tlxid';}
if($count){$sqcl=['count('.$db.'.id)']; $vm='v';}
elseif($see=='labl'){$sqcl=['ref,labels.id,icon']; $vm='kvv';}
elseif($see=='app'){$sqcl=['app,tlex_app.id,p']; $vm='kvv';}
elseif($see=='tag'){$sqcl=['tag,tlex_tag.id']; $vm='kv';}
elseif($see=='mnt'){$sqcl=['tousr,tlex_mnt.id']; $vm='kv';}
if(is_numeric($from))$sqnd[]=$db.'.id<'.$from; elseif(is_numeric($since))$sqnd[]=$db.'.id>'.$since;
if($labl)$sqnd[]='labels.id="'.$labl.'"';
if($id)$sqnd[]=$db.'.id='.$id;
//elseif($ib)$sqnd[]='ib='.$ib;//childs
elseif($ib)$sqnd[]=self::sql_thread($ib,'childs');
elseif($ia)$sqnd[]=self::sql_thread($ia,'parents');
elseif($th)$sqnd[]=self::sql_thread($th,'thread');
//elseif($th)$sqnd[]='tlex.id in select id from tlex as t2 where ib=tlex.id;';
elseif($srh)$sqnd[]='((name="'.$srh.'" or txt like "%'.$srh.'%") and (privacy=0 or uid="'.ses('uid').'"))';
elseif($ntf){$sqcl[]='tlex_ntf.id as ntid,byusr,typntf,state';
	$sqin[]='left join tlex_ntf on txid='.$db.'.id and typntf in (1,2,3)'; $sqnd[]='4usr="'.$us.'"';}
elseif($mnt)$sqnd[]='tousr="'.$usr.'"';
elseif($tag)$sqnd[]='tag="'.$tag.'"';
//elseif($liks)$sqnd[]='luid="'.$usid.'"';
elseif($list)$sqnd[]='list="'.$list.'"';
elseif($app)$sqnd[]='app="'.$app.'"';
elseif($noab)$sqnd[]='name="'.$usr.'"';
elseif($mode=='private')$sqnd[]='name="'.$usr.'"';
//elseif($answ)$sqnd[]='ib="'.$answ.'"';
//if($mode=='private')$sqnd[]='name="'.$usr.'"';
//elseif($mode=='public')$sqnd[]='name="'.$usr.'"';
///redo//else $sqnd[]='(privacy="0" or 0=(select wait from tlex_ab where usr="'.$usid.'" and tlex_ab.ab=tlex.uid))';//name!="'.$usr.'" and
if(!$noab && !$th)$sqnd[]='((pv=3 and tousr="'.$us.'") or (pv=2 and tlex_ab.usr="'.$usid.'") or pv<"'.($usid?2:1).'")';//(pv=4 and uid="'.$usid.'") or uid="'.$usid.'" or
//if(!$noab && !$th && !$app && !$tag && !$id && !$ntf)$sqnd[]='name!="'.$usr.'"';
if(!$id && !$see)$gr=' group by '.$db.'.id';//if(!$count)
if($ia or $ib or $th)$ord=' order by '.$db.'.id asc limit 40';
elseif(!$count && !$id && !$th && !$see && !$ntf)$ord=' order by '.$db.'.id desc limit 40';
elseif($ntf)$ord=' order by ntid desc limit 20';
//$sqcl=[$db.'.id'];
//pr(array_merge($sqcl,$sqin,$sqnd,[$gr],[$ord]));
$cols=implode(',',$sqcl); if($sqin)$in=implode("\n",$sqin); $w=implode(' and ',$sqnd);
$rt=sql::read($cols,self::$db,$vm,$in.' where '.$w.$gr.$ord,$z);
//profiles
$ra=array_column($rt,'uid'); $ra=array_flip(array_flip($ra)); //pr($ra);
//$ru=array_column($rt,'usr'); $ru=array_flip(array_flip($ru)); pr($ru);
$rb=sql::read('id,pname,avatar,clr,privacy','profile','rid',['id'=>$ra]); //pr($rb);
foreach($rt as $k=>$v)$rt[$k]=array_merge($v,$rb[$v['uid']]); //pr($rt);
//likes//$sqcl[]='tlex_lik.id as lid'; $sqin[]='left join tlex_lik on '.$db.'.id=lik';
$rc=sql::read('lik,id as lid,luid','tlex_lik','kv',['lik'=>$ra]); //pr($rc);
foreach($rt as $k=>$v)$rt[$k]=array_merge($v,['lid'=>$rc[$v['uid']]??'']); //pr($rt);
//members
//if($v=='members'){$sqcl[]='list';//usr,ab
//	if($mode=='public' or $tag or $app)$abs=''; else $abs=' and tlex_ab.usr="'.$usid.'"';
//	$sqin[]='left join tlex_ab on '.$db.'.uid=ab and wait=0 and block=0'.$abs;}
//$rd=sql::read('ab,list','tlex_ab','kv',['ab'=>$ra]); pr($rd);
//foreach($rt as $k=>$v)$rt[$k]=array_merge($v,['list'=>$rd[$v['uid']]??'']); pr($rt);
return $rt;}*/

//lib
/*function utf_r($r,$o=''){$rt=[];
foreach($r as $k=>$v){
	if(is_array($v))$rt[$k]=utf_r($v,$o);
	else $rt[$k]=$o?str::utf8dec($v):str::utf8enc($v);}
return $rt;}*/

///ajax
/*function jsonput0(keys,res){var cb,k,typ;
var obj=JSON.parse(res); var rk=keys.split(';'); pr(keys);
for(var i in obj){k=rk[i]; cb=getbyid(k);
	if(cb!=null)var typ=cb.type; //var type=typ.split('-')[0];
	if(typ=='text' || typ=='textarea' || typ=='hidden')cb.value=obj[i];
	else cb.innerHTML=obj[i];}}*/

//2508
//lib
/*function clrneg0($p,$o=0){if(!$p)return '000000'; $p=str_pad(substr($p,-1),6,$p);
if(!ctype_xdigit($p))return;
if($o)return hexdec($p)<6388607?'ffffff':'000000';
for($i=0;$i<3;$i++){$d=dechex(255-hexdec(substr($p,$i*2,2))); $d=str_pad($d,2,'0',STR_PAD_LEFT);}
return $d;}*/

//2503
//tlex
#action
/*static function actions($p,$txt){$rt=[]; $sz=''; $us=ses('usr');
[$id,$idv,$uid,$usr,$lg,$pv,$lbl]=vals($p,['id','idv','uid','usr','lg','pv','lbl']);
$pr='pn'.$idv; $own=$usr==$us?1:0;
if($txt)$obj=conn::call(['msg'=>$txt,'app'=>'conn','mth'=>'appreader']); //pr($r=conn::$obj);
if($lg && $lg!=ses('lng'))$rt[]=toggle($pr.'|tlxf,translate|id='.$id.',lg='.$lg,langpi('translate'));
$rt[]=toggle($pr.'|tlxf,editor|idv='.$idv.',to='.$usr.',ib='.$id,langpi('reply',$sz));
$rt[]=toggle($pr.'|tlxf,editor|idv='.$idv.',qo='.$id,langpi('relay',$sz));
$rt[]=toggle($pr.'|tlxf,share|id='.$id,langpi('share',$sz));
if(conn::$obj)$rt[]=toggle($pr.'|tlxf,keep|idv='.$idv.',id='.$id,langpi('keep',$sz));//
if($own or auth(6))$rt[]=toggle($pr.'|tlxf,redit|id='.$id,langpi('modif'),'');
else $rt[]=toggle($pr.'|tlxf,report|idv='.$idv.',id='.$id.',cusr='.$usr,langpi('report'),'');
$rt[]=tlxf::app_action($obj,$pr);
if($own)$rt[]=toggle($pr.'|tlxf,editpv|idv='.$idv.',id='.$id.',pv='.$pv,langpi('privacy'),'');
//if($own)$rt[]=bj($pr.'|tlxf,editlbl|idv='.$idv.',id='.$id.',lbl='.$lbl,langp('label'),'');
$n=chat::count($id);
$rt[]=toggle($pr.'|chat,discussion|id='.$id,langpi('discussion').' '.span($n,'liknb'));//if($usr!=$us)
if($own or auth(6))$rt[]=toggle($pr.'|tlxf,del|idv='.$idv.',did='.$id,langpi('delete'),'');//??own
return span(implode(' ',$rt),'');}*/


//select tlex.id,uid,txt,lg,pv,ib,ko,unix_timestamp(tlex.up) as now,name,pname,avatar,clr,privacy,tlex_lik.id as lid,ref,icon,lbl,list,tousr,app,p from tlex left join login on login.id=uid left join profile on puid=uid left join tlex_lik on tlex.id=lik left join labels on lbl=labels.id left join tlex_ab on tlex.uid=ab and wait=0 and block=0 and tlex_ab.usr="1" left join tlex_mnt on tlex.id=tlex_mnt.tlxid left join tlex_app on tlex.id=tlex_app.tlxid where (privacy="0" or 0=(select wait from tlex_ab where usr="1" and tlex_ab.ab=tlex.uid)) and ((pv=3 and tousr="dav") or (pv=2 and tlex_ab.usr="1") or pv<"2") group by tlex.id order by tlex.id desc limit 40

/*static function apisql0($p,$z=0){
$ra=['tm','th','id','ib','ia','srh','ntf','from','since','list','noab','labl','count','app','tag','mnt','see','mode','likes'];
[$usr,$th,$id,$ib,$ia,$srh,$ntf,$from,$since,$list,$noab,$labl,$count,$app,$tag,$mnt,$see,$mode,$liks]=vals($p,$ra);
if($from=='wrp')return;
$vm='rr'; $gr=''; $ord=''; $db=self::$db; $sqin=[]; $us=ses('usr'); $usid=ses('uid');
$cfg=['profile','like','labels'];
if(!$noab){$cfg[]='members'; $cfg[]='mentions';}
//if($labl or $see=='labl')$cfg[]='labels'; else
if($tag or $see=='tag')$cfg[]='tags';
//elseif($app or $see=='app')
$cfg[]='apps';
if(is_numeric($from))$sqnd[]=$pr['id<']=$from;
elseif(is_numeric($since))$pr['id>']=$since;
elseif($id)$pr['id']=$id;
elseif($ib)$pr['id']=self::sql_thread2($ib,'childs');
elseif($ia)$pr['id']=self::sql_thread2($ia,'parents');
elseif($th)$pr['id']=self::sql_thread2($th,'thread');
elseif($srh)$pr+=['|name'=>$srh,'%txt'=>$srh,'privacy'=>0,'uid'=>ses('uid')];

$pr['_order']=$ord; $pr['_limit']='id desc';
$ra=sql('id,uid,txt,lg,pv,ib,ko,unix_timestamp('.$db.'.up) as now','tlex','rr',$pr);
$ids=array_column($ra,'id');
$uids=array_column($ra,'uid');

foreach($cfg as $k=>$v)//activations
	if($v=='profile'){$rt['profile']=sql('pname,avatar,clr,privacy','profile','',['puid'=>$ids]);}
	elseif($v=='like'){$pr=['lik'=>$ids]; if($liks)$pr['luid']=$usid;
		$rt['tlex_lik']=sql('id as lid','tlex_lik','',$pr);}
	elseif($v=='members'){$sqcl[]='list';//usr,ab
		if($mode=='public' or $tag or $app)$pr=[]; else $pr=['usr'=>$usid];
		$sqin[]='left join tlex_ab on '.$db.'.uid=ab and wait=0 and block=0'.$abs;
		$pr['ab']=$uids;
		$rt['members']=sql('id,usr,ab','tlex_ab','',$pr+['wait'=>'0','block'=>'0']);}
	elseif($v=='labels'){$pr=['id'=>$lbl]; 
		$rt['labels']=sql('id,ref,icon,lbl','labels','',$pr);}//$lbl??
	elseif($v=='mentions'){$pr=['tlxid'=>$ids]; if($mnt)$pr['tousr']=$usr;
		$rt['mentions']=sql('id,tousr','tlex_mnt','',$pr);}
	elseif($v=='tags'){$pr=['tlxid'=>$ids]; if($tag)$pr['tag']=$tag;
		$rt['tags']=sql('id,tag','tlex_tag','',$pr);}
	elseif($v=='apps'){$pr=['tlxid'=>$ids]; if($app)$pr['app']=$app;
		$rt['apps']=sql('id,app,p','tlex_app','',$pr);}

if($ntf){$pr=['txid'=>$ids,'typntf'=>[1,2,3],'4usr'=>$us];
	$rt[]=sql('id as ntid,byusr,typntf,state','tlex_ntf','',$pr);}

return $ra;}*/

//trash23
///profile

/*static function edit0($p){
$usr=$p['usr']??ses('user');
//$usr=$p['usr']; $own=isown($usr); if(!$own)$usr=ses('user');
//$cols='id,puid,pusr,pname,status,clr,avatar,banner,web,gps,location,privacy,oAuth,ntf,role';
//$r=sql($cols,self::$db,'ra','where puid="'.ses('uid').'"'); //pr($r);
$r=self::datas($usr);
$t=tag('h2','',langp('identity'));
$reb=div(self::status_edit($r),'');
$ret=div($t.$reb,'board');
//$reb.=div(self::banner_edit($r,$p['sz']),'');
//$reb.=div(self::avatar_edit($r,$p['sz']),'');
$t=tag('h2','',langp('location'));
if($r['gps'])$del=bj('prfloc|profile,gpsav',pic('delete')); else $del='';
$reb=div(lang('location').' '.self::gps($r).$del,'','prfloc');
$ret.=div($t.$reb,'board');
//$t=tag('h2','',langp('boot'));
//$ret.=div($t.self::opening($p),'board');
$t=tag('h2','',langp('mail'));
$reb=div(self::mail_edit($r),'','prml');
$ret.=div($t.$reb,'board');
$t=tag('h2','',langp('notifications'));
$ret.=div($t.div(self::ntfbt($r),'','prnt'),'board');
$t=tag('h2','',langp('privacy'));
$ret.=div($t.div(self::privbt($r),'','prvc'),'board');
$t=tag('h2','',langp('Api'));//if(auth(6)){}
$ret.=div($t.self::oAuth($r),'board');
$t=tag('h2','',langp('twitterApi')).hlpbt('twitterApi');
$ret.=div($t.app('admin_twitter'),'board');
$t=tag('h2','',langp('modif password'));
$ret.=div($t.div(self::modifpass($r),'','mdfp'),'board');
$t=tag('h2','',langp('remove account'));
$ret.=div($t.self::deleteaccount($r),'board');
return div($ret,'','');}*/

//lib
/*function textarearesize($id,$v){$js=atj('strcount',$id).atj('autoResizeHeight',$id);
	$r=['id'=>$id,'placeholder'=>lang('message'),'class'=>'resizearea scroll2','onkeydown'=>$js,'onkeyup'=>$js,'onpaste'=>$js];
	return div(tag('textarea',$r,$v));}*/

//utlis.js
/*function resizearea(id){var ob=getbyid(id);
	ob.addEventListener('keyup',autoResizeHeight,true);//true:once
	ob.addEventListener('paste',autoResizeHeight,true);}*/

//trash22

//lib
#embed_detect
/*function ecart($v,$a,$b){$min=$a+1; $max=$b-$a-1; return substr($v,$min,$max);}

function recursearch($v,$ab,$ba,$aa){//r�actualise le nombre de balises
$tag=ecart($v,$ab,$ba);
$nb_aa=substr_count($tag,'<'.$aa);
$nb_bb=substr_count($tag,'</'.$aa);
$nb=$nb_aa-$nb_bb;
if($nb>0){for($i=0;$i<$nb;$i++){$ba=strpos($v,'</'.$aa,$ba+1);}
	$ba=recursearch($v,$ab,$ba,$aa);}
return $ba;}

function embed_detect($v,$in){
$aa_end=strpos($in,' '); $ret=''; $ba='';
if($aa_end!==false)$aa=substr($in,1,$aa_end-1);
else $aa=str_replace(['<','>'],'',$in);
$aa=strpos($v,$in);
if($aa===false){$vb=str_replace("\n",' ',$v); $aa=strpos($vb,$in);}
$ab=strpos($v,'>',$aa);
if(strpos($v,'</'.$aa.'>'))$ba=strpos($v,'</'.$aa.'>',$ab);
if($ba)$ret=ecart($v,$ab,$ba);
$aab=strpos($v,'<'.$aa,$ab);
if($aab!==false && $ba){
	$ba=recursearch($v,$ab,$ba,$aa);//!
	$ret=ecart($v,$ab,$ba);}
return $ret;}*/


//ne donne pas le nom des dossiers
/*function scandir_r($dr){$r=opendir($dr); $rt=[];
while($f=readdir($r))if($f!='..' && $f!='.' && $f!='_notes'){$df=$dr.'/'.$f;
	if(is_dir($df))$rt[]=scandir_r($df); else $rt[]=$df;}
return $rt;}*/

//sql

//equivalences:
/*1:0,1
2:1,0
3:2,1
4:5,0
6:3,2
7:1,2*/

/*static function cols0($b,$o=0){//old
$rb=self::types($b); if(!isset($rb))return; //pr($rb);
//0:[id,uid,xxx,up];1:id,uid,xxx,up;2:[uid,xxx];3:uid,xxx;4:[xxx];5:xxx,6:[0=>xxx],7:[0=>uid+xxx],8:[0=>xx]
if($o==2 or $o==4 or $o==5 or $o==6 or $o==8)array_shift($rb);//or $o==3
if($o==2 or $o==3 or $o==4 or $o==5 or $o==6 or $o==8)if(isset($rb['up']))unset($rb['up']);//az,a,vk,k,v
if($o==4 or $o==5 or $o==6)unset($rb['uid']); if($o==7)array_shift($rb);
if($o==1 or $o==3 or $o==5)return implode(',',array_keys($rb));
if($o==6 or $o==7)return array_keys($rb);
if($o==8){
	if(isset($rb['uid']))unset($rb['uid']);
	if(isset($rb['pub']))unset($rb['pub']);
	if(isset($rb['edt']))unset($rb['edt']);
	return array_keys($rb);}
return $rb;}*/

/*static function conform_length($r,$b){
$rc=self::cols($b,2); $rb=['bint'=>36,'var'=>255,'bvar'=>1020,'svar'=>60];
foreach($r as $k=>$v){$ty=$rc[$k]??''; $n=$rb[$ty];
if(strlen($v)>$n)$r[$k]=substr($v,0,$n);}
return $r;}*/

//core
/*function sqlcls0($db,$o=0){$a=0;$b=0;//patch
//0:[id,uid,xxx,up];1:id,uid,xxx,up;2:[uid,xxx];3:uid,xxx;4:[xxx];5:xxx,6:[0=>xxx],7:[0=>uid+xxx],8:[0=>xx]
if($o==1){$a=0; $b=1;}
if($o==2){$a=2; $b=0;}
if($o==3){$a=2; $b=1;}
if($o==4){$a=3; $b=0;}
if($o==5){$a=3; $b=1;}
if($o==6){$a=3; $b=2;}
if($o==7){$a=2; $b=2;}
if($o==8){$a=4; $b=2;}
return sqlcls($db,$a,$b);}*/

//condorcet
/*for($i=1;$i<=$nb;$i++){$note=$rn[$i]??''; $ex='';
	foreach($rt as $k=>$v)if($k!=$i && $v==$note)$ex=$k;
	if($note){if(!$ex)$rt[$i]=$note; else{
		for($ia=1;$ia<=$nb;$ia++)if(!in_array($ia,$rt))$rt[$i]=$ia;}}}
foreach($rt as $k=>$v)if($k!=$ka)sqlup(self::$db2,'val',$v,['choice'=>$k]);*/

/*static function note0($p){$id=$p['id']; $uid=ses('uid');
$w=['bid'=>$id,'uid'=>$uid,'choice'=>$p['choice']];
$idnote=sql('id',self::$db2,'v',$w,0);
if(!$idnote)$p['idnote']=sqlsav(self::$db2,[$id,$uid,$p['choice'],$p['val']]);
else sqlup(self::$db2,'val',$p['val'],$idnote);
if($uid)self::redefine($id,$p);
return self::build($p);}*/

/*static function pane0($rb,$closed,$rn,$nb,$id){$ret=[];
if(!ses('uid'))$com='popup|core,help|ref=loged_needed';
else $com='pb'.$id.'|condorcet,note|id='.$id;//note button
$ret['_'][]=''; for($i=1;$i<=self::$mnt;$i++)$ret['_'][]=$i;
for($i=1;$i<=$nb;$i++){
	$answer=ico('plus-square-o').' '.$rb[$i]??''; $rt=[$answer];
	$noted=count($rn)==$nb?1:0; //$noted=$closed;
	//if(auth(6))$noted=0;
	$notedcase=$rn[$i]??'';
	for($k=1;$k<=self::$mnt;$k++){
		$ico=$k==$notedcase?ico('square'):ico('square-o');
		if($closed)$rt[]=span($ico);
		else $rt[]=bj($com.',choice='.$i.',val='.$k,$ico);}
	$ret[]=$rt;}
return tabler($ret);}*/

//judgment
/*static function savcsv0($p){
$id=$p['id']??''; $d=$p['datas']??''; $b=self::$db2;
$r=explode_r($d,"\n",','); $com=array_shift($r);
if(auth(6))sqlup(self::$db,'com',implode('|',$com),$id);
$cl=array_keys(sqlcls($b,3,0));
foreach($r as $k=>$v){$id=array_shift($v);
if(auth(6))sqlups($b,array_combine($cl,$v),$id,'',0);}
return self::collect($p);}*/

//spitable3

/*static function legend0($o){$i=0; $ret='';
$r=self::$clr; $w=100; $h=20; $y=1; $x=1; $max=self::$max;
[$mode,$clr,$size]=expl('-',$o,3); if(!$mode)$mode=self::$mode;
$sz=[1=>74,2=>104,3=>88,4=>124,5=>72,6=>68,7=>50,8=>94,9=>88,10=>68,11=>70];
foreach($r as $k=>$v)if($k){$i++;
	$w=$sz[$i];//$w=strlen($k)*8;
	$ret.='[#'.$v.',gray:attr]';
	$ret.='['.$x.','.$y.','.$w.','.$h.':rect]';
	$ret.='[black,:attr]['.($x+4).','.($y+16).',font-size:12px*'.$k.':text]';
	$x+=$w;}
$ret.='['.($x+4).',16,9*@Davy 2003-2022:text]';
$s='12px'; $j='[spt|spitable3;call|p1='.$max; $s='font-size:12px';
if($mode=='linear')$ret.=$j.';p2=radial*[0,40,'.$s.'*linear:text]:bj]';
else $ret.=$j.';p2=linear*[0,40,'.$s.'*radial:text]:bj]';
$ret.=$j.';p2='.$mode.'-1*[40,40,'.$s.'*clr1:text]:bj]';
$ret.=$j.';p2='.$mode.'-2*[65,40,'.$s.'*clr2:text]:bj]';
$ret.=$j.';p2='.$mode.'-3*[100,40,'.$s.'*atomic mass:text]:bj]';
$ret.=$j.';p2='.$mode.'-4*[180,40,'.$s.'*mass:text]:bj]';
$ret.=$j.';p2='.$mode.'-5*[220,40,'.$s.'*fusion:text]:bj]';
$ret.=$j.';p2='.$mode.'-6*[260,40,'.$s.'*ebulition:text]:bj]';
if(auth(4)){
$ret.='[coloriz(1)*[40,60,'.$s.'*clr1:text]:js]';
$ret.='[coloriz(2)*[65,60,'.$s.'*clr2:text]:js]';
$ret.='[coloriz2(9)*[100,60,'.$s.'*atomic mass:text]:js]';
$ret.='[coloriz2(8)*[180,60,'.$s.'*mass:text]:js]';
$ret.='[coloriz2(5)*[220,60,'.$s.'*fusion:text]:js]';
$ret.='[coloriz2(6)*[260,60,'.$s.'*ebulition:text]:js]';
$ret.='[play(0)*[320,40,'.$s.'*anim:text]:js]';}
return $ret;}*/

/*static function clr3($r,$col){
$ra=array_keys_r($r,$col); $min=0; $max=0;
foreach($ra as $k=>$v){$v=str_replace(',','.',$v);
	if($v=='N/A' or $v=='---')$v='-';
	elseif(strpos($v,'@')!==false)$v=substr($v,0,strpos($v,'@'));
	elseif(strpos($v,'�')!==false)$v=substr($v,0,strpos($v,'�'));
	elseif(strpos($v,' ')!==false)$v=substr($v,0,strpos($v,' '));
	if(intval($v)<$min)$min=$v; if(intval($v)>$max)$max=$v; $ra[$k]=$v;}//pr($ra);
//$min=min($ra); $max=max($ra); 
$diff=$max-($min); $ratio=255/$diff; $ratio1=255/$max; if($min)$ratio2=255/(0-$min);
foreach($ra as $k=>$v){
	if(!is_numeric($v)){$red=127; $green=127; $blue=127;}
	elseif($min<0){
		if($v>=0){$d=round($v*$ratio1); $red=255; $green=$d; $blue=$green;}
		else{$d=0-round($v*$ratio2); $red=255-$d; $green=$red; $blue=255;}}
	elseif($min>=0){$d=round(($v-$min)*$ratio); $red=255; $green=255-$d; $blue=$green;}
	$rb[$k]=rgb2hex([$red,$green,$blue]);}
return $rb;}*/

/*static function clr2(){
$d='E42824 E53D2B E95F36 EF8744 F8B355 F7D35D C0D14A 92BF3A 72B225 5EAD25 57AB27 4FAA35 3BAB6C 12AE9F 0CA3C9 4A88C2 416BAD 4558A0 4D4B97 5D3E8E 6F398B 83378A 9C3789 B83589 D32E87';
$r=explode(' ',$d); $r[]='';
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//1-2
for($i=2;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//3-10
for($i=2;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//11-18
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//19-20
for($i=6;$i<11;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//21-30
for($i=3;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//31-36
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//37-38
for($i=6;$i<11;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//39-48
for($i=3;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//49-54
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//55-56
for($i=14;$i<21;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//57-70
for($i=6;$i<11;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//71-80
for($i=3;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//81-86
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//87-88
for($i=14;$i<21;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//89-102
for($i=6;$i<11;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//103-112
for($i=3;$i<6;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//113-118
for($i=2;$i<3;$i++){$r[]=$r[$i]; $r[]=$r[$i];}//119-120
return $r;}*/

//lib
/*function json_r($r){
foreach($r as $k=>$v){
	if(is_array($v))$ret[]=json_r($v);
	elseif(is_numeric($k))$ret[]='"'.rawurlencode($v).'"';
	else $ret[]='"'.$k.'":"'.rawurlencode($v).'"';}
if(is_numeric($k))return '['.implode(',',$ret).']';
else return '{'.implode(',',$ret).'}';}*/

//function json_dec($d){return json_decode($d,true);}


//ajax.js
/*if(post){//this.mRequest.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	//this.mRequest.setRequestHeader('Content-length',aPost.length);
	//this.mRequest.setRequestHeader('Connection','close');
	}*/

//art
/*static function preview($p){$id=$p['id']??'';
$r=sql('tit,txt',self::$db,'rw',$id); if(!$r)return; $dots='';
$t=popup('art,call|id='.$id,span(pic('art',32).' '.$r[0]),'apptit');
//$t.=lk('/art/'.$id,pic('url'),'btxt');
$txt=conn::call(['msg'=>$r[1],'app'=>'conn','mth'=>'noconn','ptag'=>'no']);
$max=strlen($txt); if($max>140)$max=strpos($txt,'.',140);
if($max>240){$max=strpos($txt,' ',140); $dots='...';}
$txt=substr($txt,0,$max+1).$dots;
$ret=div($t,'app').div($txt,'stxt').div('','clear');
return div($ret,'appicon');}*/

//lib

/*
function segment($d,$s,$e){$pa=strpos($d,$s); $ret='';
	if($pa!==false){$pa+=strlen($s); $pb=strpos($d,$e,$pa);
		if($pb!==false)$ret=substr($d,$pa,$pb-$pa); else $ret=substr($d,$pa);} return $ret;}
function portion($d,$a,$b,$na='',$nb=''){
	$pa=$na?strrpos($d,$a):strpos($d,$a); $pb=$nb?strrpos($d,$b):strpos($d,$b);
	return substr($d,$pa+1,($pb-$pa-1));}
function portion2($d,$a,$b,$na='',$nb=''){
$pa=$na?strrpos($d,$a):strpos($d,$a); if($pa!==false)$pa+=strlen($a); else $pa=0;
$pb=$nb?strrpos($d,$b,$pa):strpos($d,$b,$pa); if($pa && $pb)$d=substr($d,$pa,$pb-$pa);
elseif($pa)$d=substr($d,$pa); elseif($pb)$d=$d=substr($d,0,$pb); return $d;}*/

//function get($d){return urldecode($_GET[$d]??'');}
//function post($d,$v=''){return $_POST[$d]??$v;}

//function iter($r,$a){$rt=[]; if($r)foreach($r as $k=>$v)$rt[]=$a($k,$v); return $rt;}
//function iter_r($r,$a){$rt=[]; if($r)foreach($r as $k=>$v)$rt[]=is_array($v)?iter_r($v,$a):$a($k,$v); return $rt;}

function svgdim($f,$w=0,$h=0){$r=[$w,$h];
$d=read_file($f); if(!$d)return $r;
$w=segment($d,'width="','"');
$h=segment($d,'height="','"');
/*$dom=dom($d); if(!$dom)return $r;
$r=$dom->getElementsByTagName('svg'); //pr($r);
$w=$r[0]->getAttribute('width');
$h=$r[0]->getAttribute('height');*/
$w=str_replace('px','',$w);
$h=str_replace('px','',$h);
return [$w,$h];}

//function inpnb($id,$v,$min='',$max='',$st=1){return tag('input',['type'=>'number','id'=>$id,'name'=>$id,'value'=>$v,'min'=>$min,'max'=>$max,'step'=>$st],'',1);}
//function inpcolor($id,$v=''){return tag('input',['type'=>'color','id'=>$id,'name'=>$id,'value'=>$v],'',1);}
//function inpmail($id){return tag('input',['type'=>'mail','id'=>$id,'name'=>$id],'',1);}
//function inptel($id,$v,$pl='06-01-02-03'){return tag('input',['type'=>'tel','id'=>$id,'name'=>$id,'value'=>$v,'placeholder'=>$pl,'pattern'=>"[0-9]{2}-[0-9]{2}-[0-9]{2}-[0-9]{2}"],'',1);}

/*function atbr($d){$ret=''; $r=explode(',',$d);//make k="v" from k=v,
if($r)foreach($r as $v)if(strpos($v,'=')){[$ka,$va]=explode('=',$v); $ret.=atb($ka,$va);}
return $ret;}
function tagb($tag,$p,$t=''){//for vue
if(trim($t))return '<'.$tag.atbr($p).'>'.$t.'</'.$tag.'>';}*/
