<?php
$dbq=new mysqli('localhost','root','database','password');
$r=['index'=>'mac','boot'=>'','utf8'=>1,'noadmin'=>0,'sitename'=>'Fractal'];
$index='mac';//app to call
$macboot='';//force specific usr under app mac
$noadmin=0;//admin for owner only
$site='supersite';//name of site
?>