<?php
new sql(['localhost','root','dev','frct']);
ses::$cnfg=['utf8'=>1,'noadmin'=>0,'site'=>'Fractal','index'=>'home','usrboot'=>'','srv'=>'ffw.ovh','favicon'=>1];
?>