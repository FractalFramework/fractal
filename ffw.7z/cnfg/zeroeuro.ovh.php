<?php
new sql(['localhost','root','6Yk084Ry9je56168','ffw']);
ses::$cnfg=['site'=>'Fractal','index'=>'income','noadmin'=>0,'usrboot'=>'','srv'=>'ffw.ovh','favicon'=>8];
?>