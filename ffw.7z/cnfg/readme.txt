use [yourdomain.com].php to set your config

in cnfg :
weather.txt
deepl.txt
watson.txt
etc.