<?php
class phpnfo{
static $private=6;
static function content($p){return phpinfo();}
}
?>
