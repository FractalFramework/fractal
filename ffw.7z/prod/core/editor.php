<?php

class editor{
static $private=2;

static function call($p){}

}
?>