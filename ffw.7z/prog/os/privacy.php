<?php
class privacy{
static $private=0;
static $db='tlex_ab';
static $cols=['usr','ab','list','wait','block'];
static $typs=['int','int','var','int','int'];

}
?>