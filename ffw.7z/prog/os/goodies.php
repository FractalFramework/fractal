<?php
class goodies{
static $home=1;
static function content($p){return tlxf::apps(['b'=>'goodies']);}
}
?>